let x, y;
let radius = 30;

function setup() {
  createCanvas(400, 400);
  resetCircle();
}

function draw() {
  background(220);

  // Draw the circle
  fill(0, 150, 0);
  ellipse(x, y, radius * 2);

  // Check if the mouse is over the circle
  let d = dist(mouseX, mouseY, x, y);
  if (d < radius) {
    cursor(HAND);
  } else {
    cursor(ARROW);
  }
}

function mouseClicked() {
  let d = dist(mouseX, mouseY, x, y);
  if (d < radius) {
    resetCircle();
  }
}

function resetCircle() {
  x = random(radius, width - radius);
  y = random(radius, height - radius);
}